/*	Write the comment listing authors and program summary
*/

#include <iostream>
#include <iomanip>
#include <vector>
#include <ctime>

using namespace std;

/*	Initialize() - this function... write big picture comment here.

	Parameters:
	vector<int> &		A reference to the vector of int to create
	const int			How many ints to add to the vector
	const int			The largest random value to include

	Returns:
	void				No return value
*/

void Initialize(vector<int> & values, const int vector_size, const int max_value) {
	// You write this
}

/*	Write function comment in style of above.
*/

void Print(string title, vector<int> & values) {
	// You write this
}

/*	Write function comment in style of above.
*/

void BubbleSort(vector<int> & values) {
	// You write this
}

int main() {
	const size_t vector_size = 64;
	const int max_value = 65536;
	vector<int> values;

	srand((unsigned int) time(nullptr));
	Initialize(values, vector_size, max_value);
	Print("Before", values);
	BubbleSort(values);
	Print("After", values);

	return 0;
}